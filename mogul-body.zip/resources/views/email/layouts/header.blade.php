<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
<style type="text/css">



.footer-section img {
	width:80px;
}

.footer-menu-grid ul li {
	display: inline-block;
	margin: 0 10px;
	position: relative;
}

.footer-menu-grid ul li a {
	font-weight: 600;
	color:#328079;
	text-decoration:none;
}

.widget-social-icon ul,
.footer-menu-grid ul {
	padding:0px;
}

.footer-menu-grid ul li {
	display: inline-block;
	margin: 0 2px;
}

.widget-social-icon ul img {
	max-width:35px;
}

.copyright {
	font-size:13px;
}

</style>
<body style="margin:0px;background:#f1f1f1;padding:40px 0  40px 0;">
	<div class="container">
		<div class="header-section" style="border-top:5px solid #7aaba2;text-align:center;background:#302e2f;width:74%;margin:0px auto;">
			<img alt="" src="images/red-logo.png" style="width:100px;" />			
		</div>
		 
		<div class="body-section" style="width:70%;	margin:0px auto;box-shadow:1px 1px 10px rgba(0, 0, 0, 0.1);background:#fff;padding:20px;">