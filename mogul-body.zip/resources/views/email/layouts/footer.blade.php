

</div> 

		<div class="footer-section footer-menu-grid" style="text-align:center;padding:10px 0px 50px 0px;">			
			<p class="copyright" style="font-size:13px;float:left;width:100%;text-align:center;">© Copyrights 2019 Mogul Body. All rights reserved.</p>
		</div>  
	</div>
 </body>
</html>